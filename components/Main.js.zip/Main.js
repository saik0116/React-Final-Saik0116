import React, {Component} from 'react';
import { Container, Header, Title, Content, Footer,
        List,
        ListItem,
        FooterTab, 
        Button, 
        Left, 
        Right, 
        Body, Icon, Text, View} from 'native-base'


import {connect} from "react-redux";
import * as actions from "../actions"
import RestaurantInfos from "./RestaurantInfo";
import Details from "./Details";
                   


export class Main extends Component {

    listItems(){
        console.log("listItems");
        let count =0;
		
		if(this.props.isShowMain){
	        return (
            this.props.thisArray.map(item => {
            console.log(item);
                return <RestaurantInfos key={item.name} restaurant ={item} />      
            }));
		} else {
			return (<Details />);
		}

    };
    
    
    render() {

            
                if(this.props.isShowMain){
    console.log("isShowMain true"); 
            
        return ( 
            <Container>
            <Header><Text>My List</Text></Header>
            
                <Button style={{ width: 400, height: 50, backgroundColor: 'powderblue', justifyContent: 'center'}} onPress = {this.props.fetchData}>
            
                    <Text id = "btn1"> Load Data < /Text>
                </Button> 
            
        <List>{this.listItems()}</List>
        
            </Container>
        

        );} else {return (
            
            <Details />);}
                    
    }
    
    

};

const mapStateToProps = (state) => {
  return {
    thisArray: state.data,
    restoinfo: state.currentRest,
    isShowMain: state.isShowMain
     
  }
};
            
    
const mapDispatchToProps = (dispatch) => {
    return {
        fetchData: () => dispatch(actions.displayRestaurants())
    }
}

        
        
export default connect(mapStateToProps, mapDispatchToProps)(Main);